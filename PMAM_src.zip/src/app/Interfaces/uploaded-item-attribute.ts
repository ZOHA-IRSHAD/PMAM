export interface UploadedItemAttribute {
    // lastModifiedDate:string;
    name: string;
    size: number;
    type: string;
}
