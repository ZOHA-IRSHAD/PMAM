export interface FolderFields {
    folder_name: string;
    created_date: string,
    trash_status: string,
    count: number,
    asset_in_folder: string[],
    deleted_assets_in_folder: string
}
