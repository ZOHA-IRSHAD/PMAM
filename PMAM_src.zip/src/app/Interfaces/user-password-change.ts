export interface UserPasswordChange {
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
}
