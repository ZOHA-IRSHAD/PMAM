export interface AssetsFields {
  title: string;
  uploaded_date_string: string;
  asset_type: string;
  size: number;
}
