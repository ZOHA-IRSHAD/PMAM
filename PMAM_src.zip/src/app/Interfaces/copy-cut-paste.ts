export interface CopyCutPaste {
    'email_id': string,
    'operation': string,
    'uris': string[],
    'destination_folder': string,
    'source_folder': string
}
