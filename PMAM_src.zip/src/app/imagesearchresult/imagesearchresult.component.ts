import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagesearchresult',
  templateUrl: './imagesearchresult.component.html',
  styleUrls: ['./imagesearchresult.component.css']
})
export class ImagesearchresultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
